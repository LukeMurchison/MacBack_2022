from django.http import HttpResponse
from django.shortcuts import render
from dataclasses import dataclass

# Create your views here.
@dataclass
class Team:
    name: str
    decs: str
    members: str

def procurement(request, input):
    context = {
        'procurement' : Team("procurement", "Cooks", "Luke, Mike, Rivers, Anna, Zaul, Dylan"),
        'management' : Team("management", "Cleans", "Brooks, Chevy, Errin, Kevin, Lukas, Andrew"),
        'documentation' : Team("documentation", "Pics", "Colt, Isaiah, Cooper, Cannon, Angela, Antonio, Gabriel"),
        'community' : Team("community", "Events", "Joshua, Malcolm, Amber, J.W, Eric"),
        'key': input,

    }
    return render(request, "app/procurement.html", context)

def list(request):
    return render(request, "app/list.html")