from django.test import SimpleTestCase

# Create your tests here.

class TestHelloView(SimpleTestCase):
    def test_hello_nate(self):
        response = self.client.get("/hello/luke/")
        self.assertContains(response, "Hello, luke!")
